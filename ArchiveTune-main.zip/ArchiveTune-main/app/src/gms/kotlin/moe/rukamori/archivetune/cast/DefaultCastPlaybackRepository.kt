/*
 * ArchiveTune (2026)
 * © Rukamori — github.com/rukamori
 * GPL-3.0 License | Contributors: see git history
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

@file:OptIn(UnstableApi::class)

package moe.rukamori.archivetune.cast

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.webkit.MimeTypeMap
import androidx.core.net.toUri
import androidx.media3.cast.CastPlayer
import androidx.media3.cast.DefaultMediaItemConverter
import androidx.media3.cast.MediaItemConverter
import androidx.media3.cast.RemoteCastPlayer
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.common.PlayerTransferState
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import com.google.android.gms.cast.MediaInfo
import com.google.android.gms.cast.MediaQueueItem
import com.google.android.gms.cast.framework.CastContext
import com.google.android.gms.cast.framework.CastSession
import com.google.android.gms.cast.framework.SessionManagerListener
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import io.ktor.http.ContentType
import io.ktor.http.HttpHeaders
import io.ktor.http.HttpStatusCode
import io.ktor.server.application.ApplicationCall
import io.ktor.server.application.call
import io.ktor.server.cio.CIO
import io.ktor.server.engine.EmbeddedServer
import io.ktor.server.engine.embeddedServer
import io.ktor.server.request.header
import io.ktor.server.response.header
import io.ktor.server.response.respond
import io.ktor.server.response.respondOutputStream
import io.ktor.server.routing.get
import io.ktor.server.routing.options
import io.ktor.server.routing.routing
import timber.log.Timber
import java.io.ByteArrayInputStream
import java.io.File
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.URL
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.max
import kotlin.math.min
import com.google.android.gms.cast.MediaMetadata as CastMetadata

private const val MaxCastTransferPayloadBytes = 48 * 1024
private const val CastTransferMessageOverheadBytes = 2 * 1024
private const val CastMediaItemResolutionOverheadBytes = 512
private const val MaxCastTransferItems = 100
private const val MaxCastMetadataTextLength = 512
private const val MaxCastArtworkUriLength = 2_048

class DefaultCastPlaybackRepository(
    context: Context,
) : CastPlaybackRepository {
    private val appContext = context.applicationContext
    private val localMediaServer = LocalCastMediaServer(appContext)
    private val mutableScreenState =
        MutableStateFlow<CastScreenState>(
            CastScreenState.Success(
                CastUiState(
                    isAvailable = true,
                    isConnected = false,
                    device = null,
                    volume = 1f,
                ),
            ),
        )
    private var castContext: CastContext? = null
    private var listenerRegistered = false

    override val screenState: StateFlow<CastScreenState> = mutableScreenState

    override fun createPlayer(
        context: Context,
        localPlayer: ExoPlayer,
        mediaItemResolver: CastMediaItemResolver,
    ): Player {
        val contextResult = castContext(context)
        if (contextResult == null) {
            mutableScreenState.value = CastScreenState.Empty
            return localPlayer
        }
        registerSessionListener(contextResult)
        val converter =
            GmsCastMediaItemConverter(
                mediaItemResolver = mediaItemResolver,
                localMediaServer = localMediaServer,
            )
        val remotePlayer =
            RemoteCastPlayer
                .Builder(context.applicationContext)
                .setMediaItemConverter(converter)
                .build()
        return CastPlayer
            .Builder(context.applicationContext)
            .setLocalPlayer(localPlayer)
            .setRemotePlayer(remotePlayer)
            .setTransferCallback(SafeCastTransferCallback(localPlayer, converter))
            .build()
    }

    override fun disconnect() {
        castContext?.sessionManager?.endCurrentSession(true)
    }

    override fun setVolume(volume: Float) {
        castContext?.sessionManager?.currentCastSession?.let { session ->
            runCatching { session.setVolume(volume.coerceIn(0f, 1f).toDouble()) }
                .onFailure { Timber.tag("Cast").w(it, "Unable to set Cast volume") }
        }
    }

    private fun castContext(context: Context): CastContext? =
        castContext ?: runCatching {
            CastContext.getSharedInstance(context.applicationContext)
        }.onFailure {
            Timber.tag("Cast").w(it, "Unable to initialize CastContext")
        }.getOrNull()
            ?.also { castContext = it }

    private fun registerSessionListener(context: CastContext) {
        if (listenerRegistered) return
        context.sessionManager.addSessionManagerListener(sessionListener, CastSession::class.java)
        listenerRegistered = true
        updateState(context.sessionManager.currentCastSession)
    }

    private val sessionListener =
        object : SessionManagerListener<CastSession> {
            override fun onSessionStarting(session: CastSession) = updateState(session)

            override fun onSessionStarted(
                session: CastSession,
                sessionId: String,
            ) = updateState(session)

            override fun onSessionStartFailed(
                session: CastSession,
                error: Int,
            ) {
                localMediaServer.stop()
                updateState(null)
            }

            override fun onSessionEnding(session: CastSession) = updateState(session)

            override fun onSessionEnded(
                session: CastSession,
                error: Int,
            ) {
                localMediaServer.stop()
                updateState(null)
            }

            override fun onSessionResuming(
                session: CastSession,
                sessionId: String,
            ) = updateState(session)

            override fun onSessionResumed(
                session: CastSession,
                wasSuspended: Boolean,
            ) = updateState(session)

            override fun onSessionResumeFailed(
                session: CastSession,
                error: Int,
            ) {
                localMediaServer.stop()
                updateState(null)
            }

            override fun onSessionSuspended(
                session: CastSession,
                reason: Int,
            ) = updateState(session)
        }

    private fun updateState(session: CastSession?) {
        val device = session?.castDevice
        mutableScreenState.value =
            CastScreenState.Success(
                CastUiState(
                    isAvailable = true,
                    isConnected = session?.isConnected == true,
                    device =
                        device?.friendlyName?.let { name ->
                            CastDeviceUiModel(
                                id = device.deviceId ?: name,
                                name = name,
                            )
                        },
                    volume = session?.volume?.toFloat()?.coerceIn(0f, 1f) ?: 1f,
                ),
            )
    }
}

private class SafeCastTransferCallback(
    private val localPlayer: Player,
    private val mediaItemConverter: GmsCastMediaItemConverter,
) : CastPlayer.TransferCallback {
    private var castTransferWindow: CastTransferWindow? = null

    override fun transferState(
        sourcePlayer: Player,
        targetPlayer: Player,
    ) {
        val transferState = PlayerTransferState.fromPlayer(sourcePlayer)
        if (targetPlayer !== localPlayer) {
            val sourceItems = transferState.mediaItems
            if (sourcePlayer !== localPlayer || sourceItems.isEmpty()) {
                castTransferWindow = null
                transferState.setToPlayer(targetPlayer)
                return
            }

            val currentIndex =
                transferState.currentMediaItemIndex
                    .takeIf { it in sourceItems.indices }
                    ?: 0
            val castItems = ArrayList<MediaItem>(minOf(MaxCastTransferItems, sourceItems.size - currentIndex))
            var estimatedPayloadBytes = CastTransferMessageOverheadBytes

            for (index in currentIndex until sourceItems.size) {
                if (castItems.size == MaxCastTransferItems) break

                val mediaItem = sourceItems[index]
                val itemSizeBytes = mediaItemConverter.estimatedSerializedCastItemBytes(mediaItem)
                if (castItems.isNotEmpty() &&
                    estimatedPayloadBytes + itemSizeBytes > MaxCastTransferPayloadBytes
                ) {
                    break
                }

                castItems += mediaItem
                estimatedPayloadBytes += itemSizeBytes
                if (estimatedPayloadBytes > MaxCastTransferPayloadBytes) {
                    Timber.tag("Cast").w("The current Cast item exceeds the transfer payload budget")
                    break
                }
            }

            val endIndex = currentIndex + castItems.size
            val transferWindow =
                CastTransferWindow(
                    originalItemCount = sourceItems.size,
                    startIndex = currentIndex,
                    endIndexExclusive = endIndex,
                )
            val wasLimited = currentIndex != 0 || endIndex != sourceItems.size
            val boundedTransferState =
                if (wasLimited) {
                    transferState
                        .buildUpon()
                        .setMediaItems(castItems)
                        .setCurrentMediaItemIndex(0)
                        .build()
                } else {
                    transferState
                }
            boundedTransferState.setToPlayer(targetPlayer)
            castTransferWindow = transferWindow.takeIf { wasLimited }

            if (wasLimited) {
                Timber.tag("Cast").w(
                    "Limited Cast transfer to %d of %d queued media items (%d estimated bytes)",
                    castItems.size,
                    sourceItems.size,
                    estimatedPayloadBytes,
                )
            }
            return
        }

        val transferWindow = castTransferWindow
        castTransferWindow = null
        val localItems = localPlayer.mediaItems()
        val sourceCurrentIndex = transferState.currentMediaItemIndex
        val repairedItems = ArrayList<MediaItem>(transferState.mediaItems.size)
        var repairedCurrentIndex = 0

        transferState.mediaItems.forEachIndexed { sourceIndex, mediaItem ->
            val repairedItem =
                localItems.firstOrNull {
                    it.localConfiguration != null &&
                        mediaItem.mediaId.isNotBlank() &&
                        mediaItem.mediaId != MediaItem.DEFAULT_MEDIA_ID &&
                        it.mediaId == mediaItem.mediaId
                }
                    ?: localItems.getOrNull(sourceIndex)?.takeIf {
                        it.localConfiguration != null &&
                            (mediaItem.mediaId.isBlank() || mediaItem.mediaId == MediaItem.DEFAULT_MEDIA_ID)
                    }
                    ?: mediaItem.takeIf { it.localConfiguration != null && !it.isLocalCastProxy() }
                    ?: mediaItem
                        .mediaId
                        .takeIf { it.isNotBlank() && it != MediaItem.DEFAULT_MEDIA_ID }
                        ?.let { mediaId -> mediaItem.buildUpon().setUri(mediaId).build() }

            if (repairedItem != null) {
                if (sourceIndex == sourceCurrentIndex) {
                    repairedCurrentIndex = repairedItems.size
                }
                repairedItems += repairedItem
            }
        }

        val usedLocalItemsAsFallback = repairedItems.isEmpty()
        val playableItems =
            if (usedLocalItemsAsFallback) {
                localItems.filter { it.localConfiguration != null }
            } else {
                repairedItems
            }
        val matchingTransferWindow =
            transferWindow?.takeIf {
                it.originalItemCount == localItems.size &&
                    it.startIndex in 0..localItems.size &&
                    it.endIndexExclusive in it.startIndex..localItems.size
            }
        if (transferWindow != null && matchingTransferWindow == null) {
            Timber.tag("Cast").w("The local queue changed before the Cast queue was restored")
        }
        val omittedPrefix =
            if (!usedLocalItemsAsFallback && matchingTransferWindow != null) {
                localItems.subList(0, matchingTransferWindow.startIndex)
                    .filter { it.localConfiguration != null }
            } else {
                emptyList()
            }
        val omittedSuffix =
            if (!usedLocalItemsAsFallback && matchingTransferWindow != null) {
                localItems.subList(matchingTransferWindow.endIndexExclusive, localItems.size)
                    .filter { it.localConfiguration != null }
            } else {
                emptyList()
            }
        val currentIndexInPlayableItems =
            if (usedLocalItemsAsFallback && matchingTransferWindow != null) {
                matchingTransferWindow.startIndex + sourceCurrentIndex.coerceAtLeast(0)
            } else {
                repairedCurrentIndex
            }
        val safeCurrentIndex =
            if (playableItems.isEmpty()) {
                0
            } else {
                currentIndexInPlayableItems.coerceIn(playableItems.indices)
            }
        val restoredItems =
            if (omittedPrefix.isEmpty() && omittedSuffix.isEmpty()) {
                playableItems
            } else {
                buildList(omittedPrefix.size + playableItems.size + omittedSuffix.size) {
                    addAll(omittedPrefix)
                    addAll(playableItems)
                    addAll(omittedSuffix)
                }
            }

        transferState
            .buildUpon()
            .setMediaItems(restoredItems)
            .setCurrentMediaItemIndex(omittedPrefix.size + safeCurrentIndex)
            .build()
            .setToPlayer(targetPlayer)
    }

    private fun Player.mediaItems(): List<MediaItem> = List(mediaItemCount) { index -> getMediaItemAt(index) }

    private fun MediaItem.isLocalCastProxy(): Boolean {
        val uri = localConfiguration?.uri ?: return false
        return uri.scheme.equals("http", ignoreCase = true) && uri.path?.startsWith("/cast/local/") == true
    }
}

private data class CastTransferWindow(
    val originalItemCount: Int,
    val startIndex: Int,
    val endIndexExclusive: Int,
)

private class GmsCastMediaItemConverter(
    private val mediaItemResolver: CastMediaItemResolver,
    private val localMediaServer: LocalCastMediaServer,
) : MediaItemConverter {
    private val delegate = DefaultMediaItemConverter()

    override fun toMediaQueueItem(mediaItem: MediaItem): MediaQueueItem {
        val castMediaItem = mediaItem.withCompactCastMetadata().resolveForReceiver()
        return delegate.toMediaQueueItem(castMediaItem)
    }

    fun estimatedSerializedCastItemBytes(mediaItem: MediaItem): Int =
        delegate
            .toMediaQueueItem(mediaItem.withCompactCastMetadata())
            .toJson()
            .toString()
            .toByteArray(Charsets.UTF_8)
            .size + CastMediaItemResolutionOverheadBytes

    override fun toMediaItem(mediaQueueItem: MediaQueueItem): MediaItem =
        try {
            delegate.toMediaItem(mediaQueueItem)
        } catch (error: RuntimeException) {
            Timber.tag("Cast").w(error, "Falling back to manual Cast media item conversion")
            mediaQueueItem.toFallbackMediaItem()
        }

    private fun MediaItem.withCompactCastMetadata(): MediaItem {
        val metadata = mediaMetadata
        val artworkUri =
            metadata.artworkUri?.takeIf {
                it.toString().length <= MaxCastArtworkUriLength
            }
        val compactMetadata =
            MediaMetadata
                .Builder()
                .setTitle(metadata.title?.toString()?.take(MaxCastMetadataTextLength))
                .setSubtitle(metadata.subtitle?.toString()?.take(MaxCastMetadataTextLength))
                .setArtist(metadata.artist?.toString()?.take(MaxCastMetadataTextLength))
                .setAlbumTitle(metadata.albumTitle?.toString()?.take(MaxCastMetadataTextLength))
                .setAlbumArtist(metadata.albumArtist?.toString()?.take(MaxCastMetadataTextLength))
                .setArtworkUri(artworkUri)
                .setTrackNumber(metadata.trackNumber)
                .setDiscNumber(metadata.discNumber)
                .setReleaseYear(metadata.releaseYear)
                .setMediaType(metadata.mediaType)
                .setIsPlayable(metadata.isPlayable)
                .build()
        return buildUpon().setMediaMetadata(compactMetadata).build()
    }

    private fun MediaItem.resolveForReceiver(): MediaItem {
        val localConfiguration = localConfiguration ?: return this
        val uri = localConfiguration.uri
        val castMimeType = mediaItemResolver.mimeTypeForCast(this)
        val receiverItem =
            castMimeType
                ?.takeUnless { it == localConfiguration.mimeType }
                ?.let { mimeType -> buildUpon().setMimeType(mimeType).build() }
                ?: this
        if (uri.isHttpUrl()) return receiverItem
        if (uri.isLocalFileUrl()) {
            localMediaServer.prepare(receiverItem)?.let { return it }
        }
        localMediaServer.prepare(receiverItem, mediaItemResolver)?.let { return it }
        return mediaItemResolver.resolveForCast(receiverItem)
    }

    private fun Uri.isHttpUrl(): Boolean {
        val normalizedScheme = scheme?.lowercase(Locale.US)
        return normalizedScheme == "http" || normalizedScheme == "https"
    }

    private fun Uri.isLocalFileUrl(): Boolean {
        val normalizedScheme = scheme?.lowercase(Locale.US)
        return normalizedScheme == "content" ||
            normalizedScheme == "file" ||
            normalizedScheme == "android.resource"
    }

    private fun MediaQueueItem.toFallbackMediaItem(): MediaItem {
        val mediaInfo = media
        val mediaId =
            mediaInfo?.contentId?.trim().takeUnless { it.isNullOrEmpty() }
                ?: mediaInfo?.contentUrl?.trim().takeUnless { it.isNullOrEmpty() }
                ?: itemId.toString()
        return MediaItem
            .Builder()
            .setMediaId(mediaId)
            .setUri(mediaInfo.resolveFallbackUri(mediaId))
            .setMimeType(mediaInfo?.contentType?.trim()?.takeIf { it.isNotEmpty() })
            .setTag(mediaInfo?.toAppMediaMetadata(mediaId))
            .setMediaMetadata(mediaInfo.toMedia3Metadata(mediaId))
            .build()
    }

    private fun MediaInfo?.resolveFallbackUri(mediaId: String): Uri {
        val contentId = this?.contentId?.trim()
        if (!contentId.isNullOrEmpty()) return contentId.toUri()
        val contentUrl = this?.contentUrl?.trim()
        if (!contentUrl.isNullOrEmpty()) return contentUrl.toUri()
        return mediaId.toUri()
    }

    private fun MediaInfo?.toMedia3Metadata(mediaId: String): androidx.media3.common.MediaMetadata {
        val castMetadata = this?.metadata
        val title = castMetadata?.stringValue(CastMetadata.KEY_TITLE) ?: mediaId
        val subtitle = castMetadata?.stringValue(CastMetadata.KEY_SUBTITLE)
        val artist = castMetadata?.stringValue(CastMetadata.KEY_ARTIST) ?: subtitle
        return androidx.media3.common.MediaMetadata
            .Builder()
            .setTitle(title)
            .setSubtitle(subtitle)
            .setArtist(artist)
            .setAlbumArtist(castMetadata?.stringValue(CastMetadata.KEY_ALBUM_ARTIST))
            .setAlbumTitle(castMetadata?.stringValue(CastMetadata.KEY_ALBUM_TITLE))
            .setComposer(castMetadata?.stringValue(CastMetadata.KEY_COMPOSER))
            .setArtworkUri(castMetadata?.images?.firstOrNull()?.url)
            .apply {
                if (castMetadata?.containsKey(CastMetadata.KEY_DISC_NUMBER) == true) {
                    setDiscNumber(castMetadata.getInt(CastMetadata.KEY_DISC_NUMBER))
                }
                if (castMetadata?.containsKey(CastMetadata.KEY_TRACK_NUMBER) == true) {
                    setTrackNumber(castMetadata.getInt(CastMetadata.KEY_TRACK_NUMBER))
                }
            }.setIsPlayable(true)
            .build()
    }

    private fun MediaInfo?.toAppMediaMetadata(mediaId: String): moe.rukamori.archivetune.models.MediaMetadata {
        val castMetadata = this?.metadata
        val title = castMetadata?.stringValue(CastMetadata.KEY_TITLE) ?: mediaId
        val artistText =
            castMetadata?.stringValue(CastMetadata.KEY_ARTIST)
                ?: castMetadata?.stringValue(CastMetadata.KEY_SUBTITLE)
        val albumTitle = castMetadata?.stringValue(CastMetadata.KEY_ALBUM_TITLE)
        return moe.rukamori.archivetune.models.MediaMetadata(
            id = mediaId,
            title = title,
            artists =
                artistText
                    ?.split(",")
                    ?.mapNotNull { it.trim().takeIf(String::isNotBlank) }
                    ?.map {
                        moe.rukamori.archivetune.models.MediaMetadata
                            .Artist(id = null, name = it)
                    }.orEmpty(),
            duration = -1,
            thumbnailUrl =
                castMetadata
                    ?.images
                    ?.firstOrNull()
                    ?.url
                    ?.toString(),
            album =
                albumTitle?.let {
                    moe.rukamori.archivetune.models.MediaMetadata.Album(
                        id = it,
                        title = it,
                    )
                },
        )
    }

    private fun CastMetadata.stringValue(key: String): String? =
        if (containsKey(key)) {
            getString(key)?.trim()?.takeIf { it.isNotEmpty() }
        } else {
            null
        }
}

private class LocalCastMediaServer(
    private val context: Context,
) {
    private companion object {
        const val HTTP_REQUESTED_RANGE_NOT_SATISFIABLE = 416
        const val REMOTE_CONNECT_TIMEOUT_MS = 15_000
        const val REMOTE_READ_TIMEOUT_MS = 45_000
        const val FALLBACK_AUDIO_MIME_TYPE = "audio/mp4"
        const val DEFAULT_IMAGE_MIME_TYPE = "image/jpeg"
    }

    private val servedItems = ConcurrentHashMap<String, ServedItem>()
    private val servedArtwork = ConcurrentHashMap<String, ServedAsset>()
    private val connectivityManager = requireNotNull(context.getSystemService(ConnectivityManager::class.java))
    @Volatile private var engine: EmbeddedServer<*, *>? = null
    @Volatile private var port: Int = 0
    @Volatile private var hostAddress: String? = null

    @Synchronized
    fun prepare(
        mediaItem: MediaItem,
        mediaItemResolver: CastMediaItemResolver? = null,
    ): MediaItem? {
        val uri = mediaItem.localConfiguration?.uri ?: return null
        val host = ensureStarted() ?: return null
        val token = UUID.randomUUID().toString()
        val resolvedMimeType =
            mediaItem.localConfiguration?.mimeType
                ?.normalizedMimeType()
                ?: mimeType(uri)?.normalizedMimeType()
        servedItems[token] =
            ServedItem(
                mediaItem = mediaItem,
                uri = uri,
                mimeType = resolvedMimeType,
                mediaItemResolver = mediaItemResolver,
            )
        return mediaItem
            .withReceiverArtwork(host)
            .buildUpon()
            .setUri("http://$host:$port/cast/local/$token".toUri())
            .apply { resolvedMimeType?.let(::setMimeType) }
            .build()
    }

    @Synchronized
    fun stop() {
        servedItems.clear()
        servedArtwork.clear()
        val currentEngine = engine
        engine = null
        port = 0
        hostAddress = null
        currentEngine?.let {
            runCatching { it.stop(1000, 2000) }
                .onFailure { error -> Timber.tag("Cast").w(error, "Unable to stop local Cast media server") }
        }
    }

    @Synchronized
    private fun ensureStarted(): String? {
        val currentEngine = engine
        val currentHostAddress = hostAddress
        if (currentEngine != null && currentHostAddress != null) return currentHostAddress
        val address = lanAddress() ?: return null
        val selectedPort = randomFreePort()
        val startedEngine =
            runCatching {
                embeddedServer(CIO, port = selectedPort, host = "0.0.0.0") {
                    routing {
                        options("/cast/local/{token}") {
                            call.respondCastOptions()
                        }
                        get("/cast/local/{token}") {
                            val token = call.parameters["token"]
                            val item = token?.let(servedItems::get)
                            if (item == null) {
                                call.respond(HttpStatusCode.NotFound)
                                return@get
                            }
                            val rangeHeader = call.request.header(HttpHeaders.Range)
                            val source = withContext(Dispatchers.IO) { openSource(item, rangeHeader) }
                            if (source == null) {
                                call.respond(HttpStatusCode.NotFound)
                                return@get
                            }
                            call.respondSource(source)
                        }
                        get("/cast/artwork/{token}") {
                            val token = call.parameters["token"]
                            val artwork = token?.let(servedArtwork::get)
                            if (artwork == null) {
                                call.respond(HttpStatusCode.NotFound)
                                return@get
                            }
                            val source = openSource(artwork, call.request.header(HttpHeaders.Range))
                            if (source == null) {
                                call.respond(HttpStatusCode.NotFound)
                                return@get
                            }
                            call.respondSource(source)
                        }
                        options("/cast/artwork/{token}") {
                            call.respondCastOptions()
                        }
                    }
                }.also { it.start(wait = false) }
            }.onFailure {
                Timber.tag("Cast").w(it, "Unable to start local Cast media server")
            }.getOrNull() ?: return null
        engine = startedEngine
        port = selectedPort
        hostAddress = address
        return address
    }

    private fun MediaItem.withReceiverArtwork(host: String): MediaItem {
        val artworkUri = mediaMetadata.artworkUri ?: return this
        if (!artworkUri.isLocalFileUrl()) return this
        val token = UUID.randomUUID().toString()
        val artworkMimeType = mimeType(artworkUri) ?: DEFAULT_IMAGE_MIME_TYPE
        servedArtwork[token] = ServedAsset(uri = artworkUri, mimeType = artworkMimeType)
        return buildUpon()
            .setMediaMetadata(
                mediaMetadata
                    .buildUpon()
                    .setArtworkUri("http://$host:$port/cast/artwork/$token".toUri())
                    .build(),
            ).build()
    }

    private suspend fun ApplicationCall.respondSource(source: OpenSource) {
        addCastCorsHeaders()
        if (source.status == HttpStatusCode.RequestedRangeNotSatisfiable) {
            source.contentRange?.let { response.header(HttpHeaders.ContentRange, it) }
            source.close()
            respond(HttpStatusCode.RequestedRangeNotSatisfiable)
            return
        }
        source.use { nonNullSource ->
            response.header(HttpHeaders.AcceptRanges, "bytes")
            nonNullSource.length?.let { response.header(HttpHeaders.ContentLength, it.toString()) }
            nonNullSource.contentRange?.let { response.header(HttpHeaders.ContentRange, it) }
            respondOutputStream(
                contentType = ContentType.parse(nonNullSource.mimeType),
                status = nonNullSource.status,
            ) {
                nonNullSource.input.copyTo(this)
            }
        }
    }

    private suspend fun ApplicationCall.respondCastOptions() {
        addCastCorsHeaders()
        respond(HttpStatusCode.NoContent)
    }

    private fun ApplicationCall.addCastCorsHeaders() {
        response.header("Access-Control-Allow-Origin", "*")
        response.header("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS")
        response.header("Access-Control-Allow-Headers", "Origin, Range, Content-Type")
        response.header(
            "Access-Control-Expose-Headers",
            "Accept-Ranges, Content-Length, Content-Range, Content-Type",
        )
    }

    private fun openSource(
        item: ServedItem,
        rangeHeader: String?,
    ): OpenSource? {
        val asset = ServedAsset(uri = item.uri, mimeType = item.mimeType)
        if (item.mediaItemResolver == null) return openSource(asset, rangeHeader)
        val normalizedScheme = item.uri.scheme?.lowercase(Locale.US)
        return when (normalizedScheme) {
            "file", "content", "android.resource" -> openSource(asset, rangeHeader)
            else -> openResolvedRemoteSource(item, rangeHeader)
        }
    }

    private fun openSource(
        asset: ServedAsset,
        rangeHeader: String?,
    ): OpenSource? {
        val uri = asset.uri
        val normalizedScheme = uri.scheme?.lowercase(Locale.US)
        return when (normalizedScheme) {
            "file" -> openLocalFileSource(uri, asset.mimeType, rangeHeader)
            "content", "android.resource" -> openContentSource(uri, asset.mimeType, rangeHeader)
            else -> null
        }
    }

    private fun openLocalFileSource(
        uri: Uri,
        mimeType: String?,
        rangeHeader: String?,
    ): OpenSource? {
        val file = File(uri.path ?: return null).takeIf { it.isFile } ?: return null
        val length = file.length()
        val range = parseRange(rangeHeader, length)
        if (range == ParsedRange.Unsatisfiable) {
            return OpenSource.unsatisfiable(length)
        }
        val validRange = range as? ParsedRange.Valid
        val start = validRange?.start ?: 0L
        val end = validRange?.end ?: (length - 1L).coerceAtLeast(-1L)
        val contentLength = if (end >= start) end - start + 1L else 0L
        return OpenSource(
            input = file.inputStream().apply { skipFully(start) },
            length = contentLength,
            mimeType = mimeType ?: FALLBACK_AUDIO_MIME_TYPE,
            status = if (validRange == null) HttpStatusCode.OK else HttpStatusCode.PartialContent,
            contentRange = validRange?.let { "bytes $start-$end/$length" },
        )
    }

    private fun openContentSource(
        uri: Uri,
        mimeType: String?,
        rangeHeader: String?,
    ): OpenSource? {
        val length = contentLength(uri)
        val range = parseRange(rangeHeader, length)
        if (range == ParsedRange.Unsatisfiable) {
            return OpenSource.unsatisfiable(length)
        }
        val validRange = range as? ParsedRange.Valid
        val start = validRange?.start ?: 0L
        val end = validRange?.end ?: length?.minus(1L)
        val contentLength = end?.let { it - start + 1L }
        val input = context.contentResolver.openInputStream(uri) ?: return null
        input.skipFully(start)
        return OpenSource(
            input = BoundedInputStream(input, contentLength),
            length = contentLength ?: length,
            mimeType = mimeType ?: FALLBACK_AUDIO_MIME_TYPE,
            status = if (validRange == null) HttpStatusCode.OK else HttpStatusCode.PartialContent,
            contentRange = if (validRange != null && end != null && length != null) "bytes $start-$end/$length" else null,
        )
    }

    private fun openResolvedRemoteSource(
        item: ServedItem,
        rangeHeader: String?,
    ): OpenSource? {
        val resolved =
            item.resolvedMediaItem
                ?: item.mediaItemResolver?.let { resolver ->
                    runCatching { resolver.resolveForCastBlocking(item.mediaItem) }
                        .onFailure { Timber.tag("Cast").w(it, "Unable to resolve media item for Cast") }
                        .getOrNull()
                }?.also { item.resolvedMediaItem = it }
        val resolvedUri = resolved?.localConfiguration?.uri ?: return null
        if (!resolvedUri.isHttpUrl()) {
            val resolvedItem =
                item.copy(
                    uri = resolvedUri,
                    mimeType = resolved.localConfiguration?.mimeType ?: item.mimeType,
                    mediaItemResolver = null,
                )
            return openSource(resolvedItem, rangeHeader)
        }
        val connection =
            (URL(resolvedUri.toString()).openConnection() as HttpURLConnection).apply {
                connectTimeout = REMOTE_CONNECT_TIMEOUT_MS
                readTimeout = REMOTE_READ_TIMEOUT_MS
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", "ArchiveTune Cast")
                rangeHeader?.let { setRequestProperty(HttpHeaders.Range, it) }
            }
        return runCatching {
            val responseCode = connection.responseCode
            if (responseCode == HTTP_REQUESTED_RANGE_NOT_SATISFIABLE) {
                return@runCatching OpenSource.unsatisfiable(null, connection::disconnect)
            }
            if (responseCode >= HttpURLConnection.HTTP_BAD_REQUEST) {
                connection.disconnect()
                return@runCatching null
            }
            val responseLength = connection.getHeaderFieldLong(HttpHeaders.ContentLength, -1L).takeIf { it >= 0L }
            val responseMimeType =
                preferredMimeType(
                    declared =
                        resolved.localConfiguration?.mimeType
                            ?.normalizedMimeType()
                            ?: item.mimeType?.normalizedMimeType(),
                    upstream = connection.contentType?.normalizedMimeType(),
                )
                    ?: FALLBACK_AUDIO_MIME_TYPE
            OpenSource(
                input = connection.inputStream,
                length = responseLength,
                mimeType = responseMimeType,
                status =
                    if (responseCode == HttpURLConnection.HTTP_PARTIAL) {
                        HttpStatusCode.PartialContent
                    } else {
                        HttpStatusCode.OK
                    },
                contentRange = connection.getHeaderField(HttpHeaders.ContentRange),
                onClose = connection::disconnect,
            )
        }.getOrElse {
            connection.disconnect()
            Timber.tag("Cast").w(it, "Unable to open remote Cast stream proxy")
            null
        }
    }

    private fun contentLength(uri: Uri): Long? =
        runCatching {
            context.contentResolver.openFileDescriptor(uri, "r")?.use { descriptor ->
                descriptor.statSize.takeIf { it >= 0L }
            }
        }.getOrNull()

    private fun Uri.isHttpUrl(): Boolean {
        val normalizedScheme = scheme?.lowercase(Locale.US)
        return normalizedScheme == "http" || normalizedScheme == "https"
    }

    private fun Uri.isLocalFileUrl(): Boolean {
        val normalizedScheme = scheme?.lowercase(Locale.US)
        return normalizedScheme == "content" ||
            normalizedScheme == "file" ||
            normalizedScheme == "android.resource"
    }

    private fun mimeType(
        uri: Uri,
    ): String? =
        runCatching { context.contentResolver.getType(uri) }
            .getOrNull()
            ?.substringBefore(";")
            ?: uri.path
                ?.substringAfterLast('.', "")
                ?.takeIf { it.isNotBlank() }
                ?.lowercase(Locale.US)
                ?.let(MimeTypeMap.getSingleton()::getMimeTypeFromExtension)

    private fun preferredMimeType(
        declared: String?,
        upstream: String?,
    ): String? {
        if (declared == null) return upstream
        if (upstream == null) return declared
        val declaredBase = declared.substringBefore(';').trim()
        val upstreamBase = upstream.substringBefore(';').trim()
        if (upstreamBase.equals("application/octet-stream", ignoreCase = true) ||
            upstreamBase.equals("binary/octet-stream", ignoreCase = true)
        ) {
            return declared
        }
        if (!declaredBase.equals(upstreamBase, ignoreCase = true)) return upstream
        return when {
            upstream.contains("codecs=", ignoreCase = true) -> upstream
            declared.contains("codecs=", ignoreCase = true) -> declared
            else -> upstream
        }
    }

    private fun String.normalizedMimeType(): String? {
        val normalized = trim().takeIf(String::isNotEmpty) ?: return null
        val baseType = normalized.substringBefore(';').trim()
        return normalized.takeIf {
            baseType.contains('/') && !baseType.endsWith("/*")
        }
    }

    private fun parseRange(
        header: String?,
        length: Long?,
    ): ParsedRange? {
        if (header.isNullOrBlank() || !header.startsWith("bytes=")) return null
        val range = header.removePrefix("bytes=").substringBefore(",")
        val startText = range.substringBefore("-")
        val endText = range.substringAfter("-", "")
        val start =
            if (startText.isBlank()) {
                val suffixLength = endText.toLongOrNull()?.takeIf { it > 0L } ?: return null
                val knownLength = length ?: return null
                (knownLength - suffixLength).coerceAtLeast(0L)
            } else {
                max(0L, startText.toLongOrNull() ?: return null)
            }
        val end =
            if (startText.isBlank()) {
                length?.minus(1L)
            } else {
                endText
                    .toLongOrNull()
                    ?.let { requestedEnd -> length?.let { min(requestedEnd, it - 1L) } ?: requestedEnd }
                    ?: length?.minus(1L)
            }
        if (length != null && start >= length) return ParsedRange.Unsatisfiable
        if (end != null && end < start) return ParsedRange.Unsatisfiable
        return ParsedRange.Valid(start, end)
    }

    private fun lanAddress(): String? {
        val activeNetwork = connectivityManager.activeNetwork
        val networkAddress =
            runCatching {
                connectivityManager.allNetworks
                    .asSequence()
                    .sortedWith(
                        compareBy<android.net.Network> {
                            val capabilities = connectivityManager.getNetworkCapabilities(it)
                            when {
                                capabilities?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true -> 0
                                capabilities?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true -> 1
                                capabilities?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true -> 3
                                capabilities?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true -> 4
                                else -> 2
                            }
                        }.thenByDescending { it == activeNetwork },
                    ).flatMap { network ->
                        connectivityManager
                            .getLinkProperties(network)
                            ?.linkAddresses
                            .orEmpty()
                            .asSequence()
                            .map { it.address }
                    }.filterIsInstance<Inet4Address>()
                    .filterNot { it.isLoopbackAddress }
                    .filter { it.isSiteLocalAddress }
                    .mapNotNull { it.hostAddress }
                    .firstOrNull()
            }.getOrNull()
        if (networkAddress != null) return networkAddress

        val interfaces = NetworkInterface.getNetworkInterfaces().toList()
        return interfaces
            .asSequence()
            .filter { it.isUp && !it.isLoopback }
            .flatMap { networkInterface -> networkInterface.inetAddresses.toList().asSequence() }
            .filterIsInstance<Inet4Address>()
            .filterNot { it.isLoopbackAddress }
            .sortedByDescending { it.isSiteLocalAddress }
            .map { it.hostAddress }
            .firstOrNull()
    }

    private fun randomFreePort(): Int =
        ServerSocket(0).use { socket ->
            socket.reuseAddress = true
            socket.localPort
        }

    private data class ServedItem(
        val mediaItem: MediaItem,
        val uri: Uri,
        val mimeType: String?,
        val mediaItemResolver: CastMediaItemResolver?,
        @Volatile var resolvedMediaItem: MediaItem? = null,
    )

    private data class ServedAsset(
        val uri: Uri,
        val mimeType: String?,
    )

    private sealed interface ParsedRange {
        data class Valid(
            val start: Long,
            val end: Long?,
        ) : ParsedRange

        data object Unsatisfiable : ParsedRange
    }

    private data class OpenSource(
        val input: InputStream,
        val length: Long?,
        val mimeType: String,
        val status: HttpStatusCode,
        val contentRange: String?,
        val onClose: () -> Unit = {},
    ) : AutoCloseable {
        override fun close() {
            runCatching { input.close() }
            onClose()
        }

        companion object {
            fun unsatisfiable(
                length: Long?,
                onClose: () -> Unit = {},
            ) = OpenSource(
                input = ByteArrayInputStream(ByteArray(0)),
                length = 0L,
                mimeType = FALLBACK_AUDIO_MIME_TYPE,
                status = HttpStatusCode.RequestedRangeNotSatisfiable,
                contentRange = length?.let { "bytes */$it" },
                onClose = onClose,
            )
        }
    }

    private class BoundedInputStream(
        private val source: InputStream,
        private var remaining: Long?,
    ) : InputStream() {
        override fun read(): Int {
            val nonNullRemaining = remaining ?: return source.read()
            if (nonNullRemaining <= 0L) return -1
            val value = source.read()
            if (value >= 0) remaining = nonNullRemaining - 1L
            return value
        }

        override fun read(
            buffer: ByteArray,
            offset: Int,
            length: Int,
        ): Int {
            val nonNullRemaining = remaining ?: return source.read(buffer, offset, length)
            if (nonNullRemaining <= 0L) return -1
            val boundedLength = min(length.toLong(), nonNullRemaining).toInt()
            val read = source.read(buffer, offset, boundedLength)
            if (read > 0) remaining = nonNullRemaining - read
            return read
        }

        override fun close() = source.close()
    }

    private fun InputStream.skipFully(bytes: Long) {
        var remaining = bytes
        while (remaining > 0L) {
            val skipped = skip(remaining)
            if (skipped <= 0L) {
                if (read() == -1) return
                remaining--
            } else {
                remaining -= skipped
            }
        }
    }
}
